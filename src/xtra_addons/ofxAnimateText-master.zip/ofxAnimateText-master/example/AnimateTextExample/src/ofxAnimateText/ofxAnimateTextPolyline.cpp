/*
 *  ofxAnimateTextPolyline.cpp
 *  fontsExample
 *
 *  Created by Seth Hunter on 12/9/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "ofxAnimateTextPolyline.h"

