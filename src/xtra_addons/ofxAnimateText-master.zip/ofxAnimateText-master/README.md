ofxAnimateText
==============

An addon and example that allows you to animate text along a path at various speeds and spacings, as well as set the path smoothing and curvature properties. The example works on mac OSX 10.6+