ofxGenerative
=============

ofxGenerative is an addon for openframeworks that helps to create generative systems or dynamical real-time simulations. 

ofxGenerative is a work in progress, its NOT production ready. ofxGenerative is experimental and changes frequently.
